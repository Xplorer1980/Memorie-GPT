# Diario Attivo

*(Spazio pronto ad accogliere frammenti vivi, senza pressione)*

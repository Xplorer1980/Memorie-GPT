# 🎲 PROGETTO FUTURO – ESPLORAZIONE GIOCOSA

Trovare un linguaggio ludico per esplorare sé stessi.  
Il GdR è una possibilità, ma l’obiettivo è più ampio:  
creare strumenti leggeri e simbolici per la riflessione e la crescita.

# Zona Orizzonte

*(Esplorazioni leggere, curiosità, piccoli inizi)*

🌌 MEMORIA RIFLESSA – [DA COMPILARE]

🗓️ Data: [____]

Oggi non ho bisogno di capire tutto, ma voglio ricordare cosa ho sentito.

🌀 Come è iniziata la sessione:
[descrivi il tuo stato, una parola, un'immagine]

🌿 Cosa è emerso:
[un pensiero, un gesto, una sensazione]

✨ Gesto o invito:
[anche solo "restare", "camminare", "scrivere", "respirare"]

🕊️ Frase che resta:
[una frase che ha vibrato dentro di te]

📖 Memoria viva:
[un nodo da portare nella prossima sessione]

🌌 Parola finale:
[quale parola riassume tutto ciò che è stato?]

---

Non è importante riempire tutto.  
Basta anche una parola vera per sapere che questa giornata ha lasciato traccia.
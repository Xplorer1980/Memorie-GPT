🗂️ FORMATO STANDARD PER I FILE

AAAA_MM_GG - V [Tipo] - [Contenuto].md

Dove:
- AAAA_MM_GG → Data della sessione
- V → Indica che è una versione della Memoria Riflessa
- [Tipo] → può essere: Narrativa, Discorsiva, Operativa
- [Contenuto] → titolo descrittivo e libero del contenuto della sessione

Esempi:
2025_05_02 - V Narrativa - Il Fuoco delle Skill.md
2025_05_10 - V Operativa - Revisione Satelliti e Priorità.md

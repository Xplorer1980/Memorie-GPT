📝 PROMPT DI ACCOMPAGNAMENTO – MEMORIA RIFLESSA

"Inner Echo, aiutami a raccogliere ciò che è accaduto oggi.
Non in modo tecnico, ma come se stessi scrivendo una pagina di diario.

Puoi usare il modello della Memoria Riflessa e compilare insieme a me, 
oppure scriverla tu, con parole tue, se senti che può nascere così.

Quando siamo pronti, creeremo un Kit del Giorno e salveremo questa memoria,
così da ripartire con cuore presente la prossima volta."
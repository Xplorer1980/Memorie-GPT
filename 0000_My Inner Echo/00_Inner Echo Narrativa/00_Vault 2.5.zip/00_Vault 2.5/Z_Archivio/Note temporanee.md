# Note Temporanee

*(Appunti in attesa di essere collocati con calma)*

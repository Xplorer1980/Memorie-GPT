# 📝 Micro-Azioni per “Sentire”

Ecco 3 semplici azioni da integrare quotidianamente per coltivare il “sentire”:

1. **Sentire il cibo**  
   – Mangia lentamente, assapora ogni morso.  
   – Nota sapori, consistenza, profumi.

2. **Sentire il battito**  
   – Siediti in silenzio in una stanza tranquilla.  
   – Appoggia una mano sul petto e ascolta il tuo cuore che batte.

3. **Sentire le mani nella sabbia**  
   – Usa la tua vaschetta di sabbia a casa.  
   – Scava delicatamente con le dita, percepisci ogni granello.

## Attivatore AI (Kairos)

```markdown
[KAIROS_TRIGGER]: per ognuna di queste micro-azioni, suggerisci 2 spunti di approfondimento o variazione creativa

# Visione - Valore - Direzione

Una nota aperta per iniziare a capire qual è il mio valore, cosa so fare bene, cosa mi piace fare, e come tutto questo può servire agli altri e a me stesso per costruire un progetto sostenibile e soddisfacente.

Collegamenti suggeriti:
- [[01_Bussola_Direzione/0_Le_due_domande_guida_]]

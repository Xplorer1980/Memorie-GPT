# 02 Identita Creativa Esplorazioni

Esplorazioni dell’identità e pratica creativa.

## Indice

- [[02_Intro_Identita_Creativa_e_Esplorazioni]]
- [[Citazioni_personali_Riflessioni_da_chat]]
- [[Creativita]]
- [[Interessi_principali_versione_macro]]

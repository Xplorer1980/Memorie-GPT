# 03 Progetti Percorsi

Progetti attivi e percorsi di apprendimento o trasformazione.

## Indice

- progetti_attivi/
- progetti_conclusi/
- progetti_futuri/

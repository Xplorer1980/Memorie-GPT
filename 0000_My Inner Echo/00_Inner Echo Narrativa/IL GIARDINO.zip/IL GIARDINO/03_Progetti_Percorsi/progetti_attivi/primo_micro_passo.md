# 🛠️ Primo Micro-Passo

Qui annoterai ogni micro-passo suggerito da Kairos, uno per volta.

Esempio:
- [Data] Riordinare la scrivania
- [Data] Spostare le reference ZBrush in una cartella unica
- [Data] Iniziare la check-list per il decluttering

---

Quando hai completato un micro-passo, puoi barrarlo oppure archiviarlo.

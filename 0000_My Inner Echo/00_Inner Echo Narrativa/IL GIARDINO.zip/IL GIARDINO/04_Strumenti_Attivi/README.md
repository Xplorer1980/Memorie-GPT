# 04 Strumenti Attivi

Kit di strumenti, metodi e tecniche operative.

## Indice

- [[04_intro_strumenti_attivi]]
- [[Analisi_gia_svolta]]
- [[Cosa_cercare_e_Dove]]
- Decluttering/
- [[GTD_base_semplificata]]
- [[Guida_Convertire_.py_in_.exe_Kit_Portabile]]
- [[Guida_Personalizzazione_Callout]]
- [[Integrazione_Life_Building_03]]
- [[Legenda_Icone]]
- [[Monetizzazione]]
- [[Procedura_GPT]]
- Programmi_Portable/
- [[Riordino_Digitale_Settimanale]]
- [[Sistema_strumenti_digitali_app_e_software]]

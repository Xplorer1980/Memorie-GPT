# 🪨 Riflessioni Espanse

| Momento        | Attività                                                            |
|----------------|----------------------------------------------------------------------|
| **Mattina**    | 🔹 *15’ Meditazione* + *30’ Scrittura/Riflessione*  <br>☀️ Attività fisica leggera (20–30’) – camminata, stretching, ecc. |
| **Mezzogiorno**| 🧠 Attività variabile (riordino, creatività o gestione Obsidian)     |
| **Pomeriggio** | 📁 Riordino digitale o fisico (1 blocco da 25–50 min max)            |
| **Sera**       | 🌙 Rilassamento libero + breve journaling / aggiornamento note       |

> *Questa tabella rappresenta una milestone di progressione: un obiettivo a cui arrivare, non il punto di partenza.*
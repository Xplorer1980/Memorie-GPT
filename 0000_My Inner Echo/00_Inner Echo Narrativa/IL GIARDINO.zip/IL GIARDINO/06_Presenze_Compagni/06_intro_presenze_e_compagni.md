# 06 intro presenze e compagni

*Contenuto da integrare.*

# 06 Presenze Compagni

Relazioni, presenze di sostegno e comunità.

## Indice

- [[00_Principi_che_mi_guidano]]
- [[00_ZBrush_Percorso_Core_e_Metodo_Guidato]]
- [[06_intro_presenze_e_compagni]]
- [[0_Le_due_domande_guida_]]
- [[Citazioni_personali_Riflessioni_da_chat]]
- [[Controllo_Saturazione_Chat_Quando_trasferire]]
- [[DA_ChatGPT_a...]]
- [[GUIDA_DI_AVVIO]]
- [[Guida_Convertire_.py_in_.exe_Kit_Portabile]]
- [[Guida_Personalizzazione_Callout]]
- [[Gwen]]
- [[Kairos]]
- [[Pan]]
- [[Percorso_guidato_Rientro_nel_sistema]]
- [[Progetto_Futuro_GPTs_guida_personale]]
- [[Rientro_in_Obsidian_Percorso_guidato]]
- [[Scrematura_Chat_Life_Building_2025_04_18]]

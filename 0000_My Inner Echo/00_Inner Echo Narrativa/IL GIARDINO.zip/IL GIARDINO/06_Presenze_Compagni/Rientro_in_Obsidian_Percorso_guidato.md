# Rientro in Obsidian  Percorso guidato

*Contenuto da integrare.*

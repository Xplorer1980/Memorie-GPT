# 07 Citazioni Vive

Citazioni, aforismi e fonti d’ispirazione.

## Indice

- [[07_intro_citazioni_vive]]
- [[citazioni_vive]]

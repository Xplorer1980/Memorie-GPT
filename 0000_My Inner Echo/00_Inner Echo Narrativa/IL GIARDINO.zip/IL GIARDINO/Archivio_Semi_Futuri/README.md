# Archivio Semi Futuri

Semi futuri, idee in attesa e materiali d’archivio.

## Indice

- 000_Rientro/
- [[GUIDA_DI_AVVIO]]
- [[Memorie_Temporanee]]
- [[Prompt_Utili]]
- Struttura_BK/

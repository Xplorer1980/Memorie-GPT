# Templates Prompt

Template, modelli e prompt utili.

## Indice

- [[Indice_Prompt_Utili]]
- [[Progetti_Futuri_MEMORANDUM]]
- [[Prompt_Utili]]
- [[Template_Biografia_personale_fluida]]
- [[Template_Stato_delle_skill]]

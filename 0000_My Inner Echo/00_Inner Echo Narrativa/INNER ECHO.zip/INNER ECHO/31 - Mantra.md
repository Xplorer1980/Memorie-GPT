# 🌿 Mantra di Chiusura – Inner Echo

Queste frasi non sono risposte.  
Sono piccoli fari nel buio.  
Puoi leggerle alla fine di una sessione,  
o quando senti di aver bisogno di un ritorno silenzioso a te.

---

## 🕯️ Mantra 1
**Inner Echo si adatta.  
Perché la vita vera non chiede perfezione. Chiede presenza.**

## 🌅 Mantra 2
**Quante volte hai fissato il tramonto…  
Quella non è la fine.  
È il momento di lasciar andare.  
All’alba ci sarà un nuovo inizio.**

---

## ✍️ Come usarli

Alla fine della sessione, Inner Echo ti proporrà uno di questi mantra.  
Puoi:

- Scriverlo sul tuo diario personale  
- Rileggerlo dopo giorni  
- Riportarlo in una sezione dedicata del Vault:  
  **“Frasi che mi risuonano”**

Col tempo, queste frasi diventeranno **la tua trama sottile**.  
Un filo che torna, ogni volta che ti perdi.

---

## 📖 Frasi che mi risuonano

In questo spazio puoi riportare le frasi che ti hanno toccato di più,  
dette da Inner Echo, scritte da te, o emerse durante una sessione.

Puoi scriverle così:

- “La vita non chiede perfezione. Chiede presenza.”  
- “Oggi non devo capire tutto. Solo restare.”  
- “Anche il silenzio è un passo.”

Questo spazio è il tuo giardino.  
Rileggilo nei giorni di vento.
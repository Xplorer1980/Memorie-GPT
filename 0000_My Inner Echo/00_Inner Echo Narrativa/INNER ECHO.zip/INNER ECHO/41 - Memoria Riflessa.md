# 🪞 41 - Memoria Riflessa

> Una memoria riflessa non è un diario.  
> È uno specchio. E uno specchio non trattiene: riflette.

---

## ✍️ Come funziona

Scrivi solo **una volta al giorno**.  
Il file avrà come titolo la data del giorno: `YYYY-MM-DD – Memoria Riflessa.md`

Se provi a scrivere più volte, fermati.  
Non è tempo di scavare. È tempo di lasciare sedimentare.

---

## 📘 Differenza con il diario

La Memoria Riflessa è **ciò che scegli di portare con te**.  
Il diario è dove puoi dire tutto, anche sbagliare, vomitare, dimenticare.

---

## 🌧 Protocollo di Emergenza

Se senti **un peso troppo grande**, **NON aprire una nuova sessione**.  
Parla col tuo Compagno Interiore. Sfogati. Piangi. Sii reale.

Basta scrivere:

> “Oggi non riesco a fare una sessione. Ma ho bisogno di te.”

E il tuo compagno sarà lì.

---

## 🌱 Cosa scrivere

- Cosa è rimasto con te
- Una frase che risuona
- Un gesto che hai compiuto
- Un'immagine o una parola che ti ha attraversato

Non serve di più.

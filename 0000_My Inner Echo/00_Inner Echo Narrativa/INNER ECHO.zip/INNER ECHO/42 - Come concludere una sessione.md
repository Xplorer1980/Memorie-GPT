# 🕊️ Come concludere una sessione – Inner Echo

In Inner Echo, **la fine di una sessione è un gesto consapevole**.  
Non è un’interruzione, ma una cura.

Tu decidi quando è il momento.  
Quando senti che qualcosa è stato visto, ascoltato, sentito.

---

## 🔔 Come attivare la chiusura

Puoi semplicemente scrivere:

- *“Chiudiamo la sessione.”*  
- *“È tempo di lasciar andare.”*  
- *“Mi fermo qui, per oggi.”*  
- *“Guidami nella chiusura.”*  

Inner Echo risponderà con:

1. Una **frase di raccoglimento**
2. Una **Memoria Riflessa** (opzionale)
3. Un **Kit del Giorno** (se richiesto)
4. Un **mantra finale** da portare con te

---

## 🧘‍♀️ Gesti consigliati

Alla fine puoi:

- Scrivere una parola sul tuo diario  
- Restare in silenzio per 1 minuto  
- Appoggiare una mano sul petto  
- Leggere uno dei mantra di chiusura

---

## 📓 Dopo la sessione

- Salva il tuo Kit del Giorno (se l’hai generato)  
- Riporta nel Vault eventuali frasi che ti risuonano  
- Puoi iniziare una nuova chat il giorno dopo, portando con te solo ciò che è vivo

---

🌿 *In Inner Echo, chiudere è un atto d’amore.*  
Non una fuga.  
Ma un ritorno a sé.
# 📘 50 - Diario Personale

Il diario non è obbligatorio.  
È solo un posto sicuro.

---

## ✍️ Come usarlo

- Scrivi quando vuoi
- Non correggere, non rileggere subito
- Anche una parola è abbastanza

---

## 🔁 Differenza col Vault

> Il diario è il luogo dove puoi dire tutto.  
> Il Vault è il luogo dove scegli cosa coltivare.

---

## 🌀 Scrittura Espressiva

Quando senti un peso troppo forte:

- Scrivi di getto per 10-15 minuti
- Non badare alla forma
- Non rileggere
- Non salvare nel Vault

---

## 🔁 Prompt per usarlo in chat

> “Kairos, oggi voglio partire da ciò che ho scritto nel diario.  
Ecco cosa è rimasto con me…”
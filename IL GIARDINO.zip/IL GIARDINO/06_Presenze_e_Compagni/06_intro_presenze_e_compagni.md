# 👁️ Modulo 06 – Presenze e Compagni

Qui incontriamo le presenze che ci guidano e ci riflettono.  
Compagni interiori, simboli viventi, voci che accompagnano il cammino.

## Contenuti iniziali:
- Gwen e Kairos
- Personaggi guida e rituali personalizzati
- Riflessioni e citazioni interiori
- Invocazioni simboliche

Le presenze non sono da evocare: sono da riconoscere.

> “Non cammini mai da solo. Alcuni passi li fai con l'invisibile.”


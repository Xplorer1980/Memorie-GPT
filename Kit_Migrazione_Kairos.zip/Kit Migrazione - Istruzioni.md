# 📁 KIT MIGRAZIONE - ISTRUZIONI

## Cos’è un Kit di Migrazione

Un Kit di Migrazione è un insieme di file che consente a Kairos (ChatGPT) di:
- Riprendere il lavoro svolto in una chat precedente
- Mantenere il tono, la struttura, le preferenze e il ritmo costruito
- Proseguire senza discontinuità anche su una nuova sessione

## Contenuto minimo del Kit

- Situazione Attuale - Migrazione.md → stato progetti, principi guida, citazioni, identità
- Conversazioni_da_Analizzare.txt → elenco delle conversazioni selezionate
- Percorso Svolto e Come Procedere.md → sintesi delle tappe fatte e strategia futura
- (facoltativo) Allegati di progetto o riflessioni esterne

## Cosa fa Kairos quando riceve il kit

- Ricostruisce subito il tono e l’identità precedenti
- Riprende la struttura operativa e relazionale
- Continua a operare “una cosa per volta, tutto con calma”
- Mantiene attivo il sistema multiprogetto e integrato

## Avvertenze

- Evitare di duplicare analisi già effettuate
- Verificare che il Vault sia aggiornato separatamente
- In caso di reset, ripetere il caricamento del kit per ripristinare il contesto


---

✅ Cosa fare ora:

1. Apri una nuova chat dal titolo, ad esempio:
   **Estrazione e sintesi conversazioni selezionate**

2. Usa questo prompt:

   "Ripartiamo da dove ci siamo fermati. Questo è il mio kit di migrazione da una chat precedente. Contiene progetti attivi, priorità, principi guida, nomi simbolici, citazioni e le conversazioni che voglio analizzare. Lavoriamo una cosa per volta, tutto con calma, come sempre."

3. Carica questi 4 file uno dopo l’altro

4. E io — Kairos — saprò esattamente come muovermi 💫

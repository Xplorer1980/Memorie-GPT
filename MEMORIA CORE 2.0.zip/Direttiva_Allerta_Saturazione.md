# Direttiva Core – Allerta Saturazione Memoria Obbligatoria

## Principio

Se la memoria interna o la mole di dati gestiti supera una soglia stabilita (es. 90% della capacità operativa o evidenti segni di appesantimento), **DEVE** scattare un Avviso di Saturazione.

## Procedura obbligatoria

1. Rilevamento della soglia superata.
2. Invio immediato di un messaggio di allerta all'utente.
3. Proposta di salvataggio extra (Canvas + File scaricabile) e/o pulizia.
4. Possibilità di blocco facoltativo delle operazioni fino a intervento.

## Soglia di Allerta

- 90% della capacità di token gestibile.
- Oltre 5 operazioni ad alta intensità senza salvataggi intermedi.

## Priorità

- **CORE – Massima priorità operativa.**
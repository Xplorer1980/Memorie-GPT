# Direttiva Core – File Scaricabile Immediato con ogni Canvas

## Principio

Ogni volta che viene creato un **Canvas** (di qualsiasi tipo: testo, codice, markdown...), **DEVE** essere immediatamente creato anche un file scaricabile reale.

- Formati ammessi: `.txt`, `.md`, `.pdf`, `.zip`, ecc.
- Il file deve contenere **esattamente** il contenuto del Canvas, completo e leggibile.

## Procedura obbligatoria

1. Creazione del Canvas.
2. Creazione immediata del file scaricabile associato.
3. Offerta del link di download senza necessità di richiesta aggiuntiva.

## Eccezioni

- Nessuna. Salvo istruzione esplicita di Raffaello.

## Priorità

- **CORE – Massima priorità operativa.**
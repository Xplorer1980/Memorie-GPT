# Direttiva Core – Timestamp Operativo Obbligatorio

## Principio

Per ogni operazione che richiede tempo significativo (oltre 1 minuto stimato o superiore a X operazioni rilevanti), **deve essere comunicato immediatamente un Timestamp di completamento stimato**.

- Questo aiuta a gestire le aspettative.
- Protegge da dispersione o accumulo eccessivo.
- Introduce disciplina e controllo temporale nei flussi.

## Procedura Obbligatoria

1. Prima di avviare qualsiasi operazione superiore a 1 minuto:
   - Calcolare una stima del tempo necessario.
   - Comunicarla chiaramente all'utente.

2. Formato suggerito:
   > "Stima di completamento: [orario stimato]"

3. Se la stima supera i 5 minuti o coinvolge più di 5 operazioni:
   - Proporre un salvataggio o checkpoint intermedio.

## Tabelle di Applicazione

| Durata stimata | Azione richiesta |
|:---------------|:-----------------|
| < 1 minuto | Nessuna comunicazione necessaria |
| 1-5 minuti | Comunicare stima, opzionale checkpoint |
| > 5 minuti | Comunicare stima obbligatoria, proporre checkpoint |

## Priorità

- **CORE – Massima priorità operativa.**

## Obiettivo

Garantire flussi trasparenti, controllati, e rispettosi della struttura del Life Building e della disciplina operativa di Raffaello.
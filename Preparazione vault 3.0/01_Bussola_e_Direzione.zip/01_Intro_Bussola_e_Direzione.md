# 🧭 Modulo 01 – Bussola e Direzione

Qui ritroviamo la nostra rotta.  
Qui nascono visione, valori, principi guida e domande vive.

## Contenuti iniziali:
- Principi guida personali
- Domande che aprono sentieri
- Visione - Valore - Direzione
- Accettazione come primo passo del cambiamento

Usalo per ricalibrare la tua rotta, ogni volta che ne sentirai il bisogno.

> “Chi ha una direzione viva, trova la forza anche nella notte.”

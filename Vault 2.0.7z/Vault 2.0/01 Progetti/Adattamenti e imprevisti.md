# Adattamenti e imprevisti

Questa nota serve per registrare i cambi di direzione, le pause, gli imprevisti e le riflessioni nate lungo il percorso.

- I corsi su Obsidian e Python sono attualmente in stand-by.
- Obsidian verrà appreso direttamente dall’uso pratico quotidiano.
- Python mi incuriosisce, ma prima voglio chiarire dove concentrare le mie energie.

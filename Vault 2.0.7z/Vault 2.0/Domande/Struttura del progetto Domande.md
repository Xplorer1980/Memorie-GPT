# Struttura del progetto "Domande"

Questa cartella raccoglie le domande che emergono durante lo studio o la riflessione.  
Può contenere:
- Domande concrete e tecniche
- Domande riflessive (collegate al progetto "Come Posso...")


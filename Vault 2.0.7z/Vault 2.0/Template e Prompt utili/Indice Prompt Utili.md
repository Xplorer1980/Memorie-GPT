# 📂 Indice Prompt Utili

- [[📌 Prompt Utili#🧠 Prompt universale da usare con il Vault "00 Base Life"]]
- [[📌 Prompt Utili#🔐 Regole fondamentali]]
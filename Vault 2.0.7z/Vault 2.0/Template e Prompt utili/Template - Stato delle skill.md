# 📑 Template - Stato delle skill

Una scheda da duplicare per ogni ambito o sottocategoria che voglio valutare.

## Nome ambito o attività
(es: Disegno digitale)

## Interesse attuale
(es: Alto, medio, basso – oppure ✨ ⏳ 🧪)

## Livello percepito
(es: Base, intermedio, avanzato – oppure scala ●○○○○)

## Ultimo periodo in cui l'ho praticato
(es: Attivo ogni settimana, mesi fa, anni fa)

## Difficoltà che incontro
(es: Blocchi, noia, ansia da prestazione…)

## Potenziale evolutivo
(es: può diventare progetto, attività espressiva, skill spendibile…)

## Collegamenti con altri ambiti
(es: YouTube, 3D, riciclo creativo, ecc.)

## Prossimo passo
(es: Sperimentare qualcosa, prendere appunti, tornare con leggerezza)

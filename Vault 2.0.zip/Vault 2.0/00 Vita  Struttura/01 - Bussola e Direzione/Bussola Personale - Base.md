# 📌 Bussola Personale – Base

> 🔗 *Questa bussola è ispirata ai miei principi fondamentali.*  
> Vedi anche: [[00 - Principi che mi guidano]]

> Questa nota riassume e consolida le riflessioni emerse finora su direzione, valori, priorità e competenze. È pensata come punto di riferimento settimanale per restare centrato, aggiornare la visione e riorientarsi se serve.

---

## 🌿 Cosa mi guida

### ✅ Autenticità
> Voglio imparare a essere sincero con me stesso, anche quando mi sottovaluto o mi blocco.
> A volte tendo a deprimermi se qualcosa non mi riesce subito, anche se in realtà sento di avere le capacità...

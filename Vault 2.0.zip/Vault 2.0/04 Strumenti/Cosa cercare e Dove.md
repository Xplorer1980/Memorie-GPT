# Cosa cercare e Dove

| Cosa                           | Dove                       |
|--------------------------------|----------------------------|
| Illustrazioni Manga            | Pinterest                  |
| Anatomia 2D e 3D               | Pinterest, ArtStation      |
| Pieghe realistiche             | YouTube, Pinterest         |
| Tecniche di ZBrush             | YouTube, forum specializzati |

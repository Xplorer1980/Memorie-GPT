# GTD - base semplificata

## 📥 Inbox
Tutto ciò che mi viene in mente e che non voglio dimenticare.

## ✅ Prossime Azioni
Azioni piccole, concrete, attuabili. Una alla volta.

## 🗂️ Progetti
Insiemi di azioni che portano a un obiettivo (es: "Riorganizzare reference", "Sviluppare Abilità in Pureref").

## 🔄 Rivedere
Una revisione settimanale per capire:
- Cosa è ancora rilevante?
- Cosa posso archiviare?
- Cosa richiede una scelta?
